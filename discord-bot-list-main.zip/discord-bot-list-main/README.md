# Discord Bot List Altyapısı

## Bot List Altyapısı Lisanslıdır, Paylaşımı veya Satış İşlemi Yapması Yasaktır.

### Owner; Sôulfly#0001

- Altyapının Düzeltip Paylaşılması, Kodların Kopyalanıp Farklı Altyapıya Geçilmesi Yazaktır, Lisans Dosyasında Yazmaktadır.
- Altyapıyı Sunucularda, İzinsiz Paylaşmak Yasaktır.

### Kullanımı;
- Altyapı İçin Gerekli Modülleri İndirin.
- Sonrasında Token ve Gerekli Girilecek ve Düzeltilecek Şeyleri Koyun.
- CMD Açıp node index.js Yapıp Başlatınız.

### Altyapıda Yapmanız Gereken Hiç Bişi Yoktur, Sıkıntısız Çalışmaktadır.


# Lisans;
- Botun Sistem Kodlarını Farklı Bir Bot Üzerinden veya Kodları Değiştirmek ve Paylaşmak, Discord vb Sunucu veya Forumlarda Paylaşmak, İzinsiz Bu Altyapı ve Kodlarını Tamamen Yasaktır, Bu Gibi Olaylar İle Karşılaşırsak Telif Hakklarını Çiğnemek Sebebi İle Adli İşlemlere Başvurulacaktır.
