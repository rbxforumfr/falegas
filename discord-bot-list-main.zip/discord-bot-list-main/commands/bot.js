const Discord = require('discord.js');
const db = require('quick.db');

module.exports = {
	name: "bot",
	run: (client, message, args) => {
	 let succSize = db.get(`serverData.${message.guild.id}.succSize`) || 0;
	 let waitSize = db.get(`serverData.${message.guild.id}.waitSize`) || 0;
	 let redSize = db.get(`serverData.${message.guild.id}.redSize`) || 0;
	   
	 const embed = new Discord.MessageEmbed()
	  .setColor("BLUE")
	  .setAuthor(message.author.username, message.author.avatarURL({dynamic: true}))
	  .setTimestamp()
	  .setDescription(`Total de bots; **${succSize + waitSize + redSize}**\nBots approuvés; **${succSize}**\nBots en attente; **${waitSize}**\nBots rejetés; **${redSize}**`)
	  .setFooter(client.user.username, client.user.avatarURL())
     message.channel.send(embed)
  }
}