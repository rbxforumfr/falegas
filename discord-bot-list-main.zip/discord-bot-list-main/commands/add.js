const Discord = require('discord.js');
const db = require('quick.db');

module.exports = {
	name: "add",
	run: async(client, message, args) => {
      const embed = new Discord.MessageEmbed()
     .setColor("BLUE")
     .setAuthor(message.author.username, message.author.avatarURL({dynamic: true}))
	 .setTimestamp()
     .setFooter(client.user.username, client.user.avatarURL())
	 

	  if(message.channel.id !== client.settings.addChannel) return message.channel.send(embed.setDescription(`Cette commande uniquement <#${client.settings.addChannel}> Vous pouvez l'utiliser sur votre salon!`));
	  
	  let botID = args[0];
      if(!botID || isNaN(botID)) return message.channel.send(embed.setDescription("Veuillez entrer l'ID du bot que vous voulez ajouter."));
	  let discordBot = null;
      try {
		  discordBot = await client.users.fetch(botID);
	  }	catch {
          return message.channel.send(embed.setDescription("Je n'ai pas trouver de bot correspondant a cet id."));
	  }		

	  if(!discordBot.bot) return message.channel.send(embed.setDescription("Veuillez entrer l'ID du bot, ne pas entrer l'ID utilisateur!"));
	  let bot =  db.fetch(`serverData.${message.guild.id}.botsData.${botID}`);
	  
 
	  if(bot) {
		let member = await client.users.fetch(bot.owner);
        return message.channel.send(`<a:no:727544475433566330> **${discordBot.username}** Bot nommé pour le système **${member.username}** Statut ajouté par; **${bot.status}**`)
	 }
	
	  db.add(`serverData.${message.guild.id}.waitSize`, 1)
	  db.set(`serverData.${message.guild.id}.botsData.${botID}.owner`,  message.author.id)
	  db.set(`serverData.${message.guild.id}.botsData.${botID}.status`, "en attendant")
	  
      let sira = db.fetch(`serverData.${message.guild.id}.waitSize`) || 0;
	   
	message.guild.channels.cache.get(client.settings.logChannel).send(
	  embed
	  .setDescription(`Un Bot a été ajouté au système **${sira}** Bot disponible!`)
	  .addField("**À propos soumis**",`${message.author} (**${message.author.tag}**)`)
	  .addField("**À propos du Bot**", `\`${discordBot.tag}\`(**${discordBot.id}**)`)
	  )
        message.react(client.settings.emoji)
  }
}