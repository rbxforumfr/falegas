const Discord = require('discord.js');
const db = require('quick.db');

module.exports = {
	name: "kontrol-et",
	run: async(client, message, args) => {
	  if(!message.member.roles.cache.has(client.settings.modRole)) return message.channel.send(embed.setDescription("Désolé, vous n'avez pas l'autorisation requise pour utiliser cette commande"))

      let obj = await db.get(`serverData.${message.guild.id}.botsData`) || {}
	  let array1 = []
	  let array2 = []
	  let array3 = []
	  let veri = Object.keys(obj).forEach(botID => {
        if(obj[botID].status == "Approuvé" && !message.guild.members.cache.get(botID)){
		   array1.push({ID:botID})
		} else if(obj[botID].status == "Refusé" && message.guild.members.cache.get(botID)){
		    array2.push({ID:botID})
		} else if(obj[botID].status == "en attendant" && message.guild.members.cache.get(botID)){
		   array3.push({ID:botID})
		}
	  })
	  let botEkle = (ID) => `https://discord.com/oauth2/authorize?client_id=${ID}&scope=bot&permissions=0` 
	 let map = (arr) => arr.map(data => `(**${data.ID}**) | [add (0)](${botEkle(data.ID)})`).slice(0, 5).join("\n")
	  let map2 = (arr) => arr.map(data => `<@${data.ID}>`).join(", ")
	    const embed = new Discord.MessageEmbed()
		.setColor("BLUE")
        .setAuthor(message.author.username, message.author.avatarURL({dynamic: true}))
	    .addField("**Approuvé et non attaché**",  array1.length > 5 ? map(array1) + ".." : array1.length >= 1 ? map(array1) : "Liste vide") 
	    .addField("**Rejeté et attaché**",  array2.length > 5 ? map2(array2).slice(0, 5) + ".." : array2.length >= 1 ? map2(array2) :"Liste vide")
		.addField("**En attente et joint**",  array3.length > 5 ? map2(array3).slice(0, 5) + ".." : array3.length >= 1 ? map2(array3) :"Liste vide")
	    .setTimestamp()
        .setFooter(client.user.username, client.user.avatarURL())
		message.channel.send(embed)
  }
}