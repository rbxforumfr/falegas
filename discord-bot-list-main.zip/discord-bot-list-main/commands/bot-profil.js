const Discord = require('discord.js');
const db = require('quick.db');

module.exports = {
	name: "bot-profil",
	run: async(client, message, args) => {
	let botID = args[0]
	const embed = new Discord.MessageEmbed()
	.setColor("BLUE")
	.setAuthor(message.author.username, message.author.avatarURL({dynamic: true}))
	.setTimestamp()
	.setFooter(client.user.username, client.user.avatarURL())
	 if(!botID || isNaN(botID)) return message.channel.send(embed.setDescription("Veuillez écrire l'ID du bot dont vous souhaitez afficher le profil"));
	 let bot = db.fetch(`serverData.${message.guild.id}.botsData.${botID}`);
	 let discordBot = null;
	 try {
		 discordBot = await client.users.fetch(botID);
	 }	catch {
		return message.channel.send(embed.setDescription("Je n'ai pas trouver de bot correspondans a cet id."));
	 }	
	 
	 if(!bot) return message.channel.send(embed.setDescription(`Dans le système **${discordBot.username}** Je n'ai pas trouvé de bot a ce nom`))
	   let ownerName = await client.users.fetch(bot.owner);
	  embed.addField("Nom du bot /id", `\`${discordBot.username}\`(**${discordBot.id}**)`)
	  .addField("Createur",`\`${ownerName.username}\`(**${ownerName.id}**)`)
	  .addField("Bot Status", 
	  bot.status == "Approuvé" && !message.guild.members.cache.get(botID) 
	  ? "Approuvé (non attaché au serveur !)" 
	  : bot.status == "Reddedildi" && message.guild.members.cache.get(botID)  
	  ? "Refusé (Bot ajouté sur le serveur)"  
	  : bot.status == "Beklemede"  && message.guild.members.cache.get(botID)
	  ? "En attente (Bot ajouté sur le serveur)"
	  : bot.status)
	  if(bot.status == "Refusé") embed.addField("Refusé Pourquoi", `\`${bot.redReason}\``)
	 message.channel.send(embed)
  }
}