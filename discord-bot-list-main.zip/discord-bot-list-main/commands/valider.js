const Discord = require('discord.js');
const db = require('quick.db');

module.exports = {
	name: "valider",
	run: async(client, message, args) => {
     const embed = new Discord.MessageEmbed()
     .setColor("BLUE")
     .setAuthor(message.author.username, message.author.avatarURL({dynamic: true}))
	 .setTimestamp()
     .setFooter(client.user.username, client.user.avatarURL())

	  if(!message.member.roles.cache.has(client.settings.modRole)) return message.channel.send(embed.setDescription("Désolé, vous n'avez pas l'autorisation requise pour utiliser cette commander"))
      if(message.channel.id !== client.settings.processChannel) return message.channel.send(embed.setDescription(`Cette commande uniquement <#${client.settings.processChannel}> Vous pouvez l'utiliser sur votre salon !`));
	  let botID = args[0];
      if(!botID || isNaN(botID)) return message.channel.send(embed.setDescription("Spécifiez l'ID du Bot que vous souhaitez approuver."));
	  
	  let discordBot = null;
      try {
		  discordBot = await client.users.fetch(botID);
	  }	catch {
          return message.channel.send(embed.setDescription("Je n'ai trouver aucun bot correspondant a cette id."));
	  }	
	
	  let bot =  db.fetch(`serverData.${message.guild.id}.botsData.${botID}`);
	  if(!bot) return message.channel.send(embed.setDescription(`**${discordBot.username}** Le bot nommé n'a pas été ajouté au système auparavant.`));
	 	

      if(bot.status == "Approuvé") {
		  if(!message.guild.members.cache.get(botID)){
			  return message.channel.send(embed.setDescription(`**${discordBot.username}** Bot nommé approuvé mais non disponible sur le serveur!`))
		  }
		   return message.channel.send(embed.setDescription(`**${discordBot.username}** Bot nommé déjà approuvé !`))
	  }
	  let memberData = await client.users.fetch(bot.owner)

      if(!message.guild.members.cache.get(bot.owner)) return message.channel.send(embed.setDescription(`**${memberData.username}** Le bot ne peut pas être approuvé car l'utilisateur nommé a quitté le serveur !`));
	 message.guild.members.cache.get(bot.owner).roles.add(client.settings.devRole)
    if(bot.status == "en attendant")  db.subtract(`serverData.${message.guild.id}.waitSize`, 1)
	  if(bot.status == "Refusé")  db.subtract(`serverData.${message.guild.id}.redSize`, 1)
	  db.add(`serverData.${message.guild.id}.succSize`, 1);
	  db.set(`serverData.${message.guild.id}.botsData.${botID}.status`, "Approuvé")
	   message.react(client.settings.emoji)
	  message.guild.channels.cache.get(client.settings.logChannel).send(
	  embed.setDescription(`${memberData} (**${memberData.tag}**) votre bot \`${discordBot.tag}\`(**${discordBot.id}**) a été approuvé!`)
	  )
  }
}